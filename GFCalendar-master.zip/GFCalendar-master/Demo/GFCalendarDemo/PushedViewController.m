//
//  PushedViewController.m
//  GFCalendarDemo
//
//  Created by Mercy on 2016/11/14.
//  Copyright © 2016年 Mercy. All rights reserved.
//

#import "PushedViewController.h"

@interface PushedViewController ()

@end

@implementation PushedViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
}

@end
